let glazingPrice = [{
    glazingOption: 'Keep Original',
    price: '0',
},
{
    glazingOption: 'Sugar Milk',
    price: '0',
},
{
    glazingOption: 'Vanilla Milk',
    price: '0.5',
},
{
    glazingOption: 'Double chocolate',
    price: '1.5',
}];

let packSize = [
    {
        pack: '1',
        num: 1
    },
    {
        pack: '3',
        num: 3
    },
    {
        pack: '6',
        num: 5
    },
    {
        pack: '12',
        num: 10
    }
];
//glazing dropdown menu
let selectGlazing = document.querySelector('#glazingOptions');
for (let i = 0; i < glazingPrice; i++) {
    let glazingType = glazingPrice[i];
    let dropdownmenu = document.createElement('option');
    dropdownmenu.text = glazingType.glazingOption;
    dropdownmenu.value = glazingType.price;
}

//pack size dropdown menu
let SizePackSize = document.querySelector('#packOptions');
for (let i = 0; i < packSize.length; i++) {
    let packSizeType = packSize[i];
    let dropdownmenu = document.createElement('option');
    dropdownmenu.text = packSizeType.pack;
    dropdownmenu.value = packSizeType.value;
}

//calculate price
const basePrice = 2.49;
function calcPrice() {
    let checkoutPrice = (parseFloat(basePrice) + parseFloat(selectGlazing.value)) * parseFloat(selectPackSize.value);
    document.querySelector('.price').innerHTML = '$' + calcPrice.toFixed(2);
}

let glazingOpts = document.querySelector('#glazingOptions');
glazingOpts.addEventListener('change', calcPrice);

let packOpts = document.querySelector('#packOptions');
packOpts.addEventListener('change', calcPrice);